# Guía de Migración: Transferencia a Windows 11

Esta guía explica cómo empaquetar el sistema actual desde su computadora y transferirlo a la nueva instalación de Windows 11 en la máquina de la Dra.

---

## Paso 1: Preparar Paquete de Instalación (En su PC)

Ejecutaremos un script para crear un archivo comprimido que contenga todo el sistema y los datos listo para ser transferido.

1. Busque el archivo `CREAR_RESPALDO.ps1` en la carpeta del proyecto.
2. Haga clic derecho sobre él y seleccione **"Ejecutar con PowerShell"**.
3. Espere a que termine el proceso. Se creará un archivo ZIP (Ej: `RESPALDO_SISTEMA_NEURO...zip`).
4. **COPIE ESTE ARCHIVO ZIP A UN USB.**

### ¿Qué contiene este paquete?
- El código completo del sistema.
- La base de datos actual (`sistema_neuro.db`).
- Todas las imágenes y archivos de pacientes (`/uploads`).
- Las configuraciones necesarias para funcionar.

---

## Paso 2: Instalación Limpia en Windows 11

Una vez que tenga su Windows 11 listo y su archivo ZIP a mano:

### 1. Instalar Herramientas Previas
Descargue e instale los siguientes programas:
- **Node.js (LTS)**: [https://nodejs.org/](https://nodejs.org/) (Durante la instalación, marque todas las casillas por defecto).
- **Git**: [https://git-scm.com/](https://git-scm.com/) (Opcional, pero recomendado).
- **VS Code**: [https://code.visualstudio.com/](https://code.visualstudio.com/) (Para editar código si fuera necesario).

### 2. Copiar Archivos del Sistema (Desde su PC)
1. Conecte el USB donde guardó el archivo ZIP.
2. Copie el archivo ZIP al Escritorio de la nueva máquina.
3. Haga clic derecho sobre el ZIP y seleccione **"Extraer todo..."**.
4. Nombre la carpeta extraída como `Sistema Neuro`.
5. Abra la carpeta y asegúrese de ver los archivos internos (`backend`, `src`, etc.).

### 3. Instalar Dependencias y Construir
1. Abra la carpeta `Sistema Neuro`.
2. Busque el archivo **`INSTALAR_PM2.bat`**.
3. Haga clic derecho y seleccione "Ejecutar como Administrador".
4. Espere a que termine (instalará todo y creará la versión final del sistema).

---

## Paso 3: Iniciar el Sistema

### Opción A: Inicio Manual (Prueba)
Ejecute el archivo **`INICIAR_SISTEMA.bat`**.
Esto abrirá una ventana negra y el navegador. Si funciona, ciérrelo y pase a la Opción B.

### Opción B: Instalación Definitiva (Arranque Automático)
Para que el sistema inicie solo con Windows:

1. Ejecute el archivo **`INICIAR_SERVICIO_PM2.bat`**.
2. Al finalizar, abra una ventana de comandos (cmd) en la carpeta y escriba:
   ```bash
   pm2-startup install
   ```
   *(Esto asegura que el sistema reviva si se apaga la PC)*.

---

## Solución de Problemas Comunes

- **Error de "Policy" al ejecutar el script de respaldo**:
  Si PowerShell no le deja ejecutar el script, abra PowerShell como Administrador y ejecute: `Set-ExecutionPolicy RemoteSigned`, luego intente de nuevo.

- **La base de datos está vacía**:
  Asegúrese de que el archivo `backend/sistema_neuro.db` se haya extraído correctamente del ZIP.

- **Error de "Missing modules"**:
  Ejecute `npm install` nuevamente.
